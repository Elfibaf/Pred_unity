namespace VoiceChat
{
    public enum VoiceChatPreset
    {
        Speex_8K,
        Speex_16K,

        Alaw_4k,
        Alaw_8k,
        Alaw_16k,
        Alaw_Zlib_4k,
        Alaw_Zlib_8k,
        Alaw_Zlib_16k,

        /*
        Raw_4k,
        Raw_8k,
        Raw_16k,
        Raw_Zlib_4k,
        Raw_Zlib_8k,
        Raw_Zlib_16k,
        */
    } 
}
